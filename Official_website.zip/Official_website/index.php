<?php
include "connection.php";
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form</title>
    <!--BootStrap-->
    <script src="./Javascript/script.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</head>
<body>
    <form action="" method="post">
      <div class="container-fluid bg-danger">
        <div class="row justify-content-start">
          <div class="col">
            <img src="./image/icon.jpg" width="65" height="70">
            <span class="h2 instruction text-light mx-3 mt-1">O.Solution</span>
            <span class="h5 instruction text-warning mx-4"><b>Trust Us! We will Find Your Lost or Stolen Mobiles</b></span>
          </div>
        </div>
      </div>
        <div class = "container mt-3 bg-light">
          <div class="row justify-content-around">
            <div class="col-4 mt-4 mb-2">
              <div class="instruction mb-2 fs-5"><b>Complaint Registration Form</b></div>
            </div>
          </div>
      
        <!--Student Personal Details-->
          <div class="row g-3 mb-4">
            <div class="col-3">
              <label><b>Name</b></label>
            </div>
            <div class="col-4 justify-content-start">
              <input type="text" class="form-control" name = "name" placeholder="Full Name" required>
            </div>
          </div>
          <div class="row g-3 mb-4">
            <div class="col-3">
              <label for="reg"><b>Contact Number</b></label>
            </div>
            <div class="col-4 justify-content-start">
              <input type="text" class="form-control" name ="contact" placeholder="Phone Number" required>
            </div>
          </div>
          <div class="row g-3 mb-4">
            <div class="col-3">
              <label for="reg"><b>IMEI 1</b></label>
            </div>
            <div class="col-4 justify-content-start">
              <input type="text" class="form-control" name ="IMEI1" placeholder="IMEI 1" required>
            </div>
          </div>
          <div class="row g-3 mb-4">
            <div class="col-3">
              <label for="reg"><b>IMEI 2</b></label>
            </div>
            <div class="col-4 justify-content-start">
              <input type="text" class="form-control" name ="IMEI2" placeholder="IMEI 2" required>
            </div>
          </div>
          <div class="row g-3 mb-4">
            <div class="col-3">
              <label for="reg"><b>Aadhar Number</b></label>
            </div>
            <div class="col-4 justify-content-start">
              <input type="text" class="form-control" name ="aadhar" placeholder="xxxxxxxxxxxx" required>
            </div>
          </div>
          <div class="row g-3 mb-4">
            <div class="col-3">
              <label for="reg"><b>Missed District</b></label>
            </div>
            <div class="col-4 justify-content-start">
              <input type="TEXT" class="form-control" name ="district" placeholder="yyyyyy" required>
            </div>
          </div>
          <div class="row g-3 mb-4">
            <div class="col-3">
              <label for="reg"><b>Missed Street Address</b></label>
            </div>
            <div class="col-4 justify-content-start">
              <input type="TEXT" class="form-control" name ="street" placeholder="zz,zzzzzzz,zzzz" required>
            </div>
          </div>
          <div class="row g-3 mb-4">
            <div class="col-3">
              <label for="reg"><b>Pincode</b></label>
            </div>
            <div class="col-4 justify-content-start">
              <input type="TEXT" class="form-control" name ="pincode" placeholder="xxxxxx" required>
            </div>
          </div>
          <div class="row g-3 mb-4">
            <div class="col-3">
              <label for="reg"><b>Missed Month</b></label>
            </div>
            <div class="col-4 justify-content-start">
              <input type="TEXT" class="form-control" name ="month" placeholder="wwwwwwwwww" required>
            </div>
          </div>
          <div class="row g-3 mb-4">
            <div class="col-3">
            </div>
            <div class="col-1 justify-content-around">
            <button class="btn btn-secondary text-light btn-outline-dark" name="insert">Submit</button>
            </div>
          </div>
          <div class="row g-3 mb-4">
            <div class="col-1"><br></div>
            <div class="col-2">
        </div>
    </form>
<?php
  if(isset($_POST["insert"])){
  $Name=$_POST['name'];
  $Contact=$_POST['contact'];
  $IMEI1= $_POST['IMEI1'];
  $IMEI2= $_POST['IMEI2'];
  $Aadhar=$_POST['aadhar'];
  $District=$_POST['district'];
  $Street=$_POST['street'];
  $Pincode=$_POST['pincode'];
  $Month=$_POST['month'];
  mysqli_query($link,"insert into report values ('$Name','$Contact','$IMEI1','$IMEI2','$Aadhar','$District','$Street','$Pincode','$Month')");
  }
?>
</body>
</html>